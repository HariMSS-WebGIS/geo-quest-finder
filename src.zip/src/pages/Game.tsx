import { useState, useEffect, useRef } from "react";
import { MapContainer, TileLayer, Marker, Polyline, Popup } from "react-leaflet";
import "leaflet/dist/leaflet.css";
import L from "leaflet";
import { motion, AnimatePresence } from "framer-motion";

import { cities, City } from "@/data/cities";
import { haversineDistance, calculateScore, getAccuracyText, shuffleArray } from "@/lib/game";
import { HUD } from "@/components/game/HUD";
import { MapClickHandler } from "@/components/game/MapClickHandler";
import { ResultPanel } from "@/components/game/ResultPanel";
import { GameOver } from "@/components/game/GameOver";

// Fix Leaflet icons
delete (L.Icon.Default.prototype as any)._getIconUrl;
L.Icon.Default.mergeOptions({
  iconUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon.png',
  iconRetinaUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon-2x.png',
  shadowUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-shadow.png',
});

// Custom icons
const guessIcon = L.divIcon({ className: 'guess-marker', iconSize: [16, 16], iconAnchor: [8, 8] });
const actualIcon = L.divIcon({ className: 'actual-marker', iconSize: [16, 16], iconAnchor: [8, 8] });

type GamePhase = 'idle' | 'guessing' | 'result' | 'gameover';

interface RoundResult {
  city: City;
  guess: { lat: number; lng: number };
  distance: number;
  score: number;
}

const MAX_ROUNDS = 5;
const ROUND_TIME = 30;

export default function Game() {
  const [phase, setPhase] = useState<GamePhase>('idle');
  const [gameCities, setGameCities] = useState<City[]>([]);
  const [currentRound, setCurrentRound] = useState(0);
  
  const [totalScore, setTotalScore] = useState(0);
  const [streak, setStreak] = useState(0);
  const [timeLeft, setTimeLeft] = useState(ROUND_TIME);
  
  const [guess, setGuess] = useState<{lat: number, lng: number} | null>(null);
  const [results, setResults] = useState<RoundResult[]>([]);
  const [currentResult, setCurrentResult] = useState<RoundResult | null>(null);

  const timerRef = useRef<NodeJS.Timeout | null>(null);

  // Init game
  useEffect(() => {
    startGame();
  }, []);

  const startGame = () => {
    const shuffled = shuffleArray(cities).slice(0, MAX_ROUNDS);
    setGameCities(shuffled);
    setCurrentRound(0);
    setTotalScore(0);
    setStreak(0);
    setResults([]);
    startRound(0, shuffled);
  };

  const startRound = (roundIdx: number, citiesList = gameCities) => {
    setCurrentRound(roundIdx);
    setGuess(null);
    setCurrentResult(null);
    setTimeLeft(ROUND_TIME);
    setPhase('guessing');
    
    if (timerRef.current) clearInterval(timerRef.current);
    timerRef.current = setInterval(() => {
      setTimeLeft((prev) => {
        if (prev <= 1) {
          if (timerRef.current) clearInterval(timerRef.current);
          handleTimeOut(citiesList[roundIdx]);
          return 0;
        }
        return prev - 1;
      });
    }, 1000);
  };

  const handleTimeOut = (city: City) => {
    // 0 points, guess at 0,0 or just huge distance
    processGuess(0, 0, city, true);
  };

  const handleGuess = (lat: number, lng: number) => {
    if (phase !== 'guessing') return;
    if (timerRef.current) clearInterval(timerRef.current);
    setGuess({ lat, lng });
    processGuess(lat, lng, gameCities[currentRound], false);
  };

  const processGuess = (lat: number, lng: number, city: City, timedOut: boolean) => {
    const distance = timedOut ? 10000 : haversineDistance(lat, lng, city.lat, city.lng);
    const score = calculateScore(distance);
    
    const newStreak = score >= 3000 ? streak + 1 : 0;
    
    const roundResult = {
      city,
      guess: { lat, lng },
      distance,
      score
    };

    setStreak(newStreak);
    setTotalScore(prev => prev + score);
    setCurrentResult(roundResult);
    setResults(prev => [...prev, roundResult]);
    setPhase('result');
  };

  const handleNextRound = () => {
    if (currentRound + 1 >= MAX_ROUNDS) {
      setPhase('gameover');
      
      // Save best score
      const saved = localStorage.getItem("geospy_best_score");
      const best = saved ? parseInt(saved, 10) : 0;
      if (totalScore > best) {
        localStorage.setItem("geospy_best_score", totalScore.toString());
      }
    } else {
      startRound(currentRound + 1);
    }
  };

  useEffect(() => {
    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, []);

  if (phase === 'idle' || gameCities.length === 0) return null;

  if (phase === 'gameover') {
    return (
      <GameOver 
        score={totalScore} 
        maxScore={MAX_ROUNDS * 5000} 
        results={results} 
        onPlayAgain={startGame} 
      />
    );
  }

  const currentCity = gameCities[currentRound];

  return (
    <div className="relative w-full h-[100dvh] flex flex-col bg-background overflow-hidden">
      <HUD 
        round={currentRound + 1} 
        maxRounds={MAX_ROUNDS} 
        score={totalScore} 
        streak={streak} 
        timeLeft={timeLeft} 
      />

      {/* Target City Banner */}
      <AnimatePresence mode="wait">
        {phase === 'guessing' && (
          <motion.div 
            key="target-banner"
            initial={{ y: -100, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            exit={{ y: -100, opacity: 0 }}
            className="absolute top-24 left-1/2 -translate-x-1/2 z-[1000] glass-panel px-8 py-4 rounded-2xl flex flex-col items-center text-center pointer-events-none"
          >
            <div className="text-xs uppercase tracking-widest text-primary font-bold mb-1">Locate target</div>
            <div className="text-3xl font-bold text-white">{currentCity.name}</div>
            <div className="text-sm text-muted-foreground mt-1 flex items-center gap-2">
              <span>{currentCity.country}</span>
              <span className="w-1 h-1 rounded-full bg-white/20" />
              <span>{currentCity.continent}</span>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      <div className={`w-full h-full flex-1 relative ${phase === 'guessing' ? 'cursor-crosshair' : 'cursor-default'}`}>
        <MapContainer 
          center={[20, 0]} 
          zoom={2} 
          minZoom={2}
          className="w-full h-full bg-background"
          zoomControl={false}
          scrollWheelZoom={phase === 'guessing'}
          doubleClickZoom={phase === 'guessing'}
          dragging={true}
          worldCopyJump={false}
        >
          <TileLayer
            url="https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png"
            attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors &copy; <a href="https://carto.com/attributions">CARTO</a>'
          />
          
          <MapClickHandler onGuess={handleGuess} active={phase === 'guessing'} />

          {/* Markers & Lines for Result Phase */}
          {phase === 'result' && guess && currentCity && (
            <>
              <Marker position={[guess.lat, guess.lng]} icon={guessIcon}>
                <Popup>Your Guess</Popup>
              </Marker>
              
              <Marker position={[currentCity.lat, currentCity.lng]} icon={actualIcon}>
                <Popup>{currentCity.name}</Popup>
              </Marker>
              
              <Polyline 
                positions={[[guess.lat, guess.lng], [currentCity.lat, currentCity.lng]]} 
                pathOptions={{ color: 'white', dashArray: '5, 10', weight: 2, opacity: 0.5 }} 
              />
            </>
          )}
        </MapContainer>
      </div>

      <AnimatePresence>
        {phase === 'result' && currentResult && (
          <ResultPanel 
            score={currentResult.score}
            distanceKm={currentResult.distance}
            accuracyText={getAccuracyText(currentResult.distance)}
            isLastRound={currentRound + 1 >= MAX_ROUNDS}
            onNext={handleNextRound}
          />
        )}
      </AnimatePresence>
    </div>
  );
}
