import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Globe, Crosshair, Target } from "lucide-react";
import { useEffect, useState } from "react";

export default function Home() {
  const [bestScore, setBestScore] = useState<number | null>(null);

  useEffect(() => {
    const saved = localStorage.getItem("geospy_best_score");
    if (saved) setBestScore(parseInt(saved, 10));
  }, []);

  return (
    <div className="min-h-[100dvh] w-full flex flex-col items-center justify-center bg-background text-foreground relative overflow-hidden p-6">
      {/* Background pattern */}
      <div className="absolute inset-0 opacity-[0.03] pointer-events-none" style={{ backgroundImage: 'radial-gradient(circle at 2px 2px, white 1px, transparent 0)', backgroundSize: '40px 40px' }} />
      
      <div className="z-10 w-full max-w-md flex flex-col items-center text-center space-y-8 glass-panel p-10 rounded-2xl">
        <div className="space-y-4">
          <div className="inline-flex items-center justify-center p-4 bg-primary/10 rounded-full mb-4">
            <Globe className="w-12 h-12 text-primary" />
          </div>
          <h1 className="text-5xl font-bold tracking-tight text-white font-number">Geo<span className="text-primary">Spy</span></h1>
          <p className="text-lg text-muted-foreground uppercase tracking-widest text-sm font-semibold">Global Intelligence</p>
        </div>

        <p className="text-muted-foreground text-center">
          A tactical geography challenge. Locate cities around the world with precision. Every round is a race against your own knowledge.
        </p>

        {bestScore !== null && (
          <div className="bg-white/5 border border-white/10 px-6 py-3 rounded-lg flex items-center space-x-3">
            <Target className="w-5 h-5 text-secondary" />
            <div className="text-left">
              <div className="text-xs text-muted-foreground uppercase tracking-wider">Best Score</div>
              <div className="font-number text-xl font-bold text-white">{bestScore.toLocaleString()}</div>
            </div>
          </div>
        )}

        <Link href="/game" className="w-full">
          <Button className="w-full h-14 text-lg font-bold bg-primary text-primary-foreground hover:bg-primary/90 transition-all rounded-xl" data-testid="button-start-game">
            <Crosshair className="w-5 h-5 mr-2" />
            INITIATE MISSION
          </Button>
        </Link>
      </div>
    </div>
  );
}
