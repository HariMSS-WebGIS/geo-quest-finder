export function haversineDistance(lat1: number, lng1: number, lat2: number, lng2: number): number {
  const R = 6371;
  const dLat = (lat2 - lat1) * Math.PI / 180;
  const dLng = (lng2 - lng1) * Math.PI / 180;
  const a = Math.sin(dLat/2)**2 + Math.cos(lat1 * Math.PI/180) * Math.cos(lat2 * Math.PI/180) * Math.sin(dLng/2)**2;
  return R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
}

export function calculateScore(distanceKm: number): number {
  return Math.round(5000 * Math.exp(-distanceKm / 2000));
}

export function getAccuracyText(distanceKm: number): string {
  if (distanceKm < 50) return "Perfect!";
  if (distanceKm < 200) return "Excellent!";
  if (distanceKm < 800) return "Good!";
  if (distanceKm < 2000) return "Not bad";
  if (distanceKm < 5000) return "Off target";
  return "Way off!";
}

export function getScoreColor(score: number): string {
  if (score >= 3000) return "text-green-400";
  if (score >= 1500) return "text-yellow-400";
  return "text-red-400";
}

export function shuffleArray<T>(array: T[]): T[] {
  const newArray = [...array];
  for (let i = newArray.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [newArray[i], newArray[j]] = [newArray[j], newArray[i]];
  }
  return newArray;
}
