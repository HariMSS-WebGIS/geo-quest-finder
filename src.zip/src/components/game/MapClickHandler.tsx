import { useMapEvents } from "react-leaflet";

interface MapClickHandlerProps {
  onGuess: (lat: number, lng: number) => void;
  active: boolean;
}

export function MapClickHandler({ onGuess, active }: MapClickHandlerProps) {
  useMapEvents({
    click(e) {
      if (active) {
        onGuess(e.latlng.lat, e.latlng.lng);
      }
    },
  });

  return null;
}
