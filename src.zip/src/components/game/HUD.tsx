import { motion } from "framer-motion";
import { Flame, Clock } from "lucide-react";

interface HUDProps {
  round: number;
  maxRounds: number;
  score: number;
  streak: number;
  timeLeft: number;
}

export function HUD({ round, maxRounds, score, streak, timeLeft }: HUDProps) {
  return (
    <div className="absolute top-0 left-0 w-full z-[1000] p-4 pointer-events-none">
      <div className="max-w-7xl mx-auto flex justify-between items-start gap-4">
        
        {/* Left: Round & Score */}
        <div className="flex flex-col gap-2 pointer-events-auto">
          <div className="glass-panel px-4 py-2 rounded-xl flex flex-col">
            <span className="text-[10px] uppercase tracking-wider text-muted-foreground font-bold">Mission</span>
            <span className="font-number font-bold text-lg">{round} <span className="text-muted-foreground">/ {maxRounds}</span></span>
          </div>
          
          <div className="glass-panel px-4 py-2 rounded-xl flex flex-col">
            <span className="text-[10px] uppercase tracking-wider text-muted-foreground font-bold">Score</span>
            <span className="font-number font-bold text-xl text-primary">{score.toLocaleString()}</span>
          </div>
        </div>
        
        {/* Center: Timer */}
        <div className="pointer-events-auto">
          <div className={`glass-panel px-6 py-3 rounded-full flex items-center gap-2 border-2 ${timeLeft <= 5 ? 'border-destructive text-destructive animate-pulse' : 'border-transparent'}`}>
            <Clock className="w-5 h-5" />
            <span className="font-number font-bold text-2xl w-8 text-center">{timeLeft}</span>
          </div>
        </div>
        
        {/* Right: Streak */}
        <div className="pointer-events-auto flex flex-col items-end">
          <motion.div 
            animate={{ scale: streak > 0 ? 1 : 0, opacity: streak > 0 ? 1 : 0 }}
            className="glass-panel px-4 py-2 rounded-xl flex items-center gap-2"
          >
            <Flame className={`w-5 h-5 ${streak >= 3 ? 'text-secondary' : 'text-orange-300'}`} />
            <div className="flex flex-col">
              <span className="text-[10px] uppercase tracking-wider text-muted-foreground font-bold text-right">Streak</span>
              <span className="font-number font-bold text-lg text-right">x{streak}</span>
            </div>
          </motion.div>
        </div>
        
      </div>
    </div>
  );
}
