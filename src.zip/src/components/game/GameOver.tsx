import { motion } from "framer-motion";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Trophy, RotateCcw, Home, MapPin, Target } from "lucide-react";
import { City } from "@/data/cities";

interface RoundResult {
  city: City;
  guess: { lat: number; lng: number };
  distance: number;
  score: number;
}

interface GameOverProps {
  score: number;
  maxScore: number;
  results: RoundResult[];
  onPlayAgain: () => void;
}

export function GameOver({ score, maxScore, results, onPlayAgain }: GameOverProps) {
  const stars = score >= 20000 ? 3 : score >= 10000 ? 2 : 1;
  const percentage = Math.round((score / maxScore) * 100);

  return (
    <div className="min-h-[100dvh] w-full flex flex-col items-center py-12 px-4 bg-background text-foreground relative overflow-y-auto">
      <div className="absolute inset-0 opacity-[0.02] pointer-events-none" style={{ backgroundImage: 'linear-gradient(#fff 1px, transparent 1px), linear-gradient(90deg, #fff 1px, transparent 1px)', backgroundSize: '20px 20px' }} />
      
      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="z-10 w-full max-w-2xl flex flex-col space-y-6"
      >
        <div className="glass-panel p-8 rounded-2xl flex flex-col items-center text-center space-y-6">
          <div className="uppercase tracking-widest text-sm font-bold text-primary">Mission Complete</div>
          
          <div className="flex gap-2 text-secondary">
            {[...Array(3)].map((_, i) => (
              <Trophy key={i} className={`w-12 h-12 ${i < stars ? 'fill-secondary' : 'opacity-20'}`} />
            ))}
          </div>
          
          <div className="space-y-1">
            <div className="text-7xl font-bold font-number text-white">{score.toLocaleString()}</div>
            <div className="text-muted-foreground uppercase tracking-widest text-xs font-semibold">Total Score / {maxScore.toLocaleString()}</div>
          </div>
          
          <div className="w-full bg-white/5 rounded-full h-3 overflow-hidden">
            <motion.div 
              initial={{ width: 0 }}
              animate={{ width: `${percentage}%` }}
              transition={{ duration: 1, delay: 0.5 }}
              className="h-full bg-primary"
            />
          </div>
        </div>

        <div className="glass-panel p-6 rounded-2xl space-y-4">
          <h3 className="text-sm uppercase tracking-widest font-bold text-muted-foreground mb-4">Mission Log</h3>
          
          <div className="space-y-3">
            {results.map((result, i) => (
              <motion.div 
                key={i}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.1 * i }}
                className="flex items-center justify-between p-3 rounded-lg bg-white/5 border border-white/5"
              >
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded-full bg-white/10 flex items-center justify-center font-number font-bold text-xs">{i+1}</div>
                  <div>
                    <div className="font-bold">{result.city.name}</div>
                    <div className="text-xs text-muted-foreground">{result.city.country}</div>
                  </div>
                </div>
                
                <div className="text-right flex items-center gap-4">
                  <div className="hidden sm:block">
                    <div className="text-xs text-muted-foreground flex items-center justify-end gap-1"><MapPin className="w-3 h-3" /> Distance</div>
                    <div className="font-number font-medium">{Math.round(result.distance).toLocaleString()} km</div>
                  </div>
                  <div>
                    <div className="text-xs text-primary flex items-center justify-end gap-1"><Target className="w-3 h-3" /> Score</div>
                    <div className="font-number font-bold text-white">+{result.score.toLocaleString()}</div>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </div>

        <div className="flex gap-4 w-full">
          <Button onClick={onPlayAgain} className="flex-1 h-14 text-lg font-bold bg-primary text-primary-foreground hover:bg-primary/90" data-testid="button-play-again">
            <RotateCcw className="w-5 h-5 mr-2" /> Play Again
          </Button>
          <Link href="/">
            <Button variant="outline" className="h-14 px-6 border-white/20 hover:bg-white/10 text-white" data-testid="button-home">
              <Home className="w-5 h-5" />
            </Button>
          </Link>
        </div>
      </motion.div>
    </div>
  );
}
