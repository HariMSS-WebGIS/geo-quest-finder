import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { getScoreColor } from "@/lib/game";
import { ArrowRight, Trophy } from "lucide-react";

interface ResultPanelProps {
  score: number;
  distanceKm: number;
  accuracyText: string;
  isLastRound: boolean;
  onNext: () => void;
}

export function ResultPanel({ score, distanceKm, accuracyText, isLastRound, onNext }: ResultPanelProps) {
  const distanceMi = Math.round(distanceKm * 0.621371);
  const scoreColor = getScoreColor(score);

  return (
    <motion.div 
      initial={{ opacity: 0, y: 50, scale: 0.9 }}
      animate={{ opacity: 1, y: 0, scale: 1 }}
      exit={{ opacity: 0, y: 50, scale: 0.9 }}
      className="absolute bottom-8 left-1/2 -translate-x-1/2 z-[1000] glass-panel p-6 rounded-2xl w-full max-w-sm flex flex-col items-center text-center space-y-4 shadow-2xl"
    >
      <div className="uppercase tracking-widest text-xs font-bold text-muted-foreground">{accuracyText}</div>
      
      <div>
        <div className={`text-5xl font-bold font-number ${scoreColor}`}>
          +{score.toLocaleString()}
        </div>
        <div className="text-sm text-muted-foreground mt-1">Points</div>
      </div>
      
      <div className="bg-white/5 border border-white/10 rounded-lg py-2 px-4 w-full">
        <div className="text-sm text-muted-foreground">Distance</div>
        <div className="font-number font-medium text-lg">
          {Math.round(distanceKm).toLocaleString()} km <span className="text-muted-foreground/50">/ {distanceMi.toLocaleString()} mi</span>
        </div>
      </div>
      
      <Button 
        onClick={onNext} 
        className="w-full h-12 bg-white text-black hover:bg-gray-200 font-bold"
        data-testid="button-next-round"
      >
        {isLastRound ? (
          <>View Briefing <Trophy className="w-4 h-4 ml-2" /></>
        ) : (
          <>Next Target <ArrowRight className="w-4 h-4 ml-2" /></>
        )}
      </Button>
    </motion.div>
  );
}
